Diccionario de Datos

Datos - Tipo de Datos - Ejemplo



Noticia:
- Fecha - Date -  YYYY-MM-DD
- URL noticia - varChar - https://www.elquehaydecierto.cl/noticia/medioambiente/sismo-sacudio-la-region-de-atacama-esta-manana
- Titulo - text - Sismo sacudio la region de Atacama esta semana
- Fecha Publicacion - Date - 2022-03-12
- Contenido Textual - text - "......"

Medio:

- URL medio - varChar - https://www.elquehaydecierto.cl/
- Region - varChar - III
- Pais - varChar - Chile
- Nombre del medio - varChar - Elquehaydecierto
- Fecha de creacion - Date - YYYY-MM-DD
- Idioma - varChar - Español

Adquiere:
- Fecha de Adquisicion - date - 1999-04-12

Dueños
- Nombre - varChar - Fulanito Gonzales
- Tipo - char - Natural o Empresa
- Fecha - Date - YYYY-MM-DD

Persona mencionada
- Nombre - varChar - Pedro Soto
- Wiki - varChar - wikipedia.com/Pedro_Soto
- Profesion - varChar - Paseador de Perros
- Fecha Nacimiento - Date - 1999-06-25
- Nacionalidad - varChar - Chile
---
Tiene
-Valor - varChar - +59 %
---
Popularidad
- Promedio_Vis - INT - 88
- Visitas - INT  - 108
- Fecha - Date - 2022-06-28


