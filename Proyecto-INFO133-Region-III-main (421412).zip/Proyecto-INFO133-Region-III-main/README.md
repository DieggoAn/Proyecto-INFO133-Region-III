# Proyecto-INFO133-Region-III

Region III Atacama

Nombre Integrante - Email - GitHub
    Diego Aguero - dieggoan@gmail.com - DieggoAn
    Marco Delgado - marcodelgado.1008@gmail.com - ShutUp-Pls
    Sebastian Fuentes - sebamfuentes.c@gmail.com - MatsuokiSF

Medios de comunicacion 
    Nombre - Url - Comuna

    El diario de Atacama	https://www.soychile.cl/copiapo/	                    Atacama
    Red Atacama	            http://www.redatacama.com/                           	Atacama
    Diario de Atacama	    https://www.diarioatacama.cl/                       	Atacama
    Diario Chañarcillo	    http://www.chanarcillo.cl/	                            Copiapó
    El Quehaydecierto	    http://www.elquehaydecierto.cl/	                        Copiapó
    Digital Fm Copiapó	    http://www.digitalfm.cl/	                            Copiapó
    El Calderino	        http://www.elcalderino.cl/	                            Caldera
    Tierra Amarilla 	    http://www.tierraamarillainforma.cl/	                Tierra Amarilla
    Radio Maray Copiapo	    https://www.maray.cl/	                                Copiapó
    ATACAMA NOTICIAS		www.atacamanoticias.cl                                  Copiapó
    ATACAMA EN LÍNEA		www.atacamaenlinea.cl                                   Copiapó
    Muni Chañaral           https://www.munichanaral.cl/noticias.html               Chañaral
    El noticiero del Huasco https://elnoticierodelhuasco.cl                         Huasco 
    HuascoTv                http://www.huascotelevisionstreaming.cl                 Huasco
    Noticias Huasco         https://twitter.com/NoticierodelHua                     Huasco  
    Vallenar Online         https://twitter.com/VallenarOnline                      Vallenar
    Tierra amarillano       https://twitter.com/tamarillano                         Tierra Amarilla
    Nostalgica              https://www.nostalgica.cl                               Atacama
    Radio Genesis           https://www.radiogennesis.cl                            Atacama